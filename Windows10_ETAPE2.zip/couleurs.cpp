#include <iostream>
#include <windows.h>
int main(){
 HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
 for (int i=0; i < 256 ; i++){
 SetConsoleTextAttribute(h, i);
 std::cout << i << " : texte\n";
 }
}
