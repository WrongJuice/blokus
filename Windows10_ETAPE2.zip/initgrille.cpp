/**
 * \file initGrille.cpp
 * \brief Initialise la grille.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 *
 * Initialise la grille dans le tableau de caractères et les couleurs dans le tableau d'entiers
 *
 */

#include <fonctions.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void initGrille(contenu unContenuConstant[])
{

    unContenuConstant[1].leContenu = ' '; //Début première ligne
    for (int i = 1 ; i != 21 ; ++i){
        switch (i/10) {
        default: unContenuConstant[i + 1].leContenu = '1';
                break;
        case 0: unContenuConstant[i + 1].leContenu = ' ';
                break;
        case 2: unContenuConstant[i + 1].leContenu = '2';
                break;
        }
    }

    //unContenuConstant[22].leContenu , unContenuConstant[23].leContenu , unContenuConstant[105].leContenu = ' ';
    for (int i = 1 ; i != 21 ; ++i){ //Deuxième ligne et colonne de lettres
        unContenuConstant[i + 23].leContenu = i%10 + 48;
        unContenuConstant[43 + i*2].leContenu = i + 64;
    }

    for (int i = 1 ; i != 22 ; ++i) //Construction de la ligne et la colonne "invisible"
    {
        unContenuConstant[42 + i*2].leContenu = ' ';
        unContenuConstant[84 + i].leContenu = ' ';
    }

    int uneCouleur[4];
    srand(time(NULL)); //Initialisation de rand
    for (int i = 1 ; i != 5 ; ++i)//Attribution au hasard d'un chiffre entre 1 et 4 pour chacun des 4 joueurs
    {
        switch (i) { //Switch nécessaire avec 3 boucles pour éviter que deux joueurs ou plus puissent avoir la même couleur
        case 1: uneCouleur[i] = (rand()%4) + 1;
            break;
        case 2:
            uneCouleur[i] = (rand()%4) + 1;
            while (uneCouleur[i] == uneCouleur[i - 1]) //On reboucle jusqu'à obtenir un chiffre différent du précedent
            {
                uneCouleur[i] = (rand()%4) + 1;;
            }
            break;
        case 3:
            uneCouleur[i] = (rand()%4) + 1;;
            while (uneCouleur[i] == uneCouleur[i - 1] or uneCouleur[i] == uneCouleur[i - 2]) //différent du précedent et du premier
            {
                uneCouleur[i] = (rand()%4) + 1;
            }
            break;
        case 4:
            uneCouleur[i] = (rand()%4) + 1;
            while (uneCouleur[i] == uneCouleur[i - 1] or uneCouleur[i] == uneCouleur[i - 2] or uneCouleur[i] == uneCouleur[i - 3]) //différent des trois premiers
            {
                uneCouleur[i] = (rand()%4) + 1;
            }
            break;
        }
    }
    for (int i = 1 ; i != 5 ; ++i) //Attribution d'une couleur en fonction du chiffre attribué plus haut
    {
        switch (uneCouleur[i]) {
        case 1: uneCouleur[i] = 170; //Vert
            break;
        case 2: uneCouleur[i] = 238; //Jaune
            break;
        case 3: uneCouleur[i] = 153; //Bleu
            break;
        case 4: uneCouleur[i] = 204; //Rouge
            break;
        }
    }
    unContenuConstant[23].laCouleur = uneCouleur[1];
    unContenuConstant[44].laCouleur = uneCouleur[2];
    unContenuConstant[85].laCouleur = uneCouleur[3];
    unContenuConstant[105].laCouleur = uneCouleur[4];
}
