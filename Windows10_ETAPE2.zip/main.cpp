/**
 * \file main.cpp
 * \brief Jeu blockus.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 *
 * Fonction principal du projet de jeu de société Blockus
 *
 */

#include <fonctions.h>


int main()
{
    contenu leContenuConstant[110];
    //contenu leContenuGrille[401];
    //contenu leContenuPieces[1620];
    initGrille(leContenuConstant); //On initialise une fois certains caractères et les couleurs
    std::cout << "okay !";
    //afficheGrille(); //Construction et affichage de la grille
}
