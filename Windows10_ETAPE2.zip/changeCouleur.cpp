/**
 * \file changeCouleur.cpp
 * \brief Change la couleur de la console.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 *
 * Fonction qui change la couleur de la console
 *
 */

#include <windows.h>
#include <iostream>

void changeCouleur(int uneCouleur) //Fonction permettant le changement de couleur
{
    HANDLE H = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H , uneCouleur);
}
