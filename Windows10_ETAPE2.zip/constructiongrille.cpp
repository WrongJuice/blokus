/**
 * \file constructionGrille.cpp
 * \brief Construit la grille.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 *
 * Construction de la grille en fonction des actions précedentes du joueur, plusieurs éxecutions nécessaires
 *
 */

#include <fonctions.h>

void constructionGrille(contenu unContenuGrille[])//Construction de la partie variable de la grille
{
    for (int u = 1 ; u != 21 ; ++u){ //Première boucle pour les colonnes
        for (int i = 1 ; i != 21 ; ++i){ //Deuxième boucle pour les lignes
            unContenuGrille[23 + u*22 + i].leContenu = '.'; //Affectation dans le tableau
        }
    }

}
