/**
 * \file fonctions.h
 * \brief header.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 *
 * Comprend les déclarations de fonctions, et de structures
 *
 */

#ifndef FONCTIONS_H
#define FONCTIONS_H
#include <iostream>

/**
 * \struct contenu fonctions.h fonctions
 */
struct contenu {
    int laCouleur;
    char leContenu;
};


/**
 * \fn déclaration de "initGrille"
 * \brief Fonction d'initialisation de la Grille
 *
 * \param tableau de type contenu.
 */
void initGrille(contenu unContenuConstant[]);


/**
 * \fn déclaration de "constructionGrille"
 * \brief Fonction de construction de la Grille
 *
 * \param tableau de type contenu.
 */
void constructionGrille(contenu unContenuGrille[]);


/**
 * \fn déclaration de "afficheGrille"
 * \brief Fonction d'affichage de la Grille
 *
 * \param tableau de type contenu.
 */
void afficheGrille(contenu unContenuConstant[]);


/**
 * \fn déclaration de "changeCouleur"
 * \brief Fonction de changement de la couleur de la console
 *
 * \param variable de type contenu qui contient une sous variable "laCouleur" de type int.
 */
void changeCouleur(contenu uneCouleur[]);

#endif // FONCTIONS_H

