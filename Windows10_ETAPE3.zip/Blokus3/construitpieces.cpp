/**
 * \file construitGrille.cpp
 * \brief Construit des pièces.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 */

#include <fonctions.h>
#include <fstream>

/**
 * \brief construitPieces
 * \param desPiecesJoueur
 */
void construitPieces(pieces &desPiecesJoueur)
{
    std::ifstream leFichierPieces("pieces.txt" , std::ios::app); //On ouvre en écriture notes.txt et on le nomme leFichier
    int indice = 0 ;
    for (int i = 0 ; i != 63 ; i++)
    {
        std::getline(leFichierPieces , desPiecesJoueur.lesLignesStringJoueur[i]);
        desPiecesJoueur.lesLargeursPiecesJoueur[i] = 0;
        if (desPiecesJoueur.lesLignesStringJoueur[i] == desPiecesJoueur.lesLignesStringJoueur[1]){
            desPiecesJoueur.lesLignesVides[indice] = i;
            indice++;
        }else{
            desPiecesJoueur.lesLargeursPiecesJoueur[i] = desPiecesJoueur.lesLignesStringJoueur[i].size();
        }
    }


        /*if (vide == false){
            desPiecesJoueur.lesLargeursPiecesJoueur[i] = strlen(desPiecesJoueur.lesLignesStringJoueur[i]);
        }*/
    desPiecesJoueur.unePiece[0] = "x";
    int compteur = 1;
    for (int i = 1 ; i != 62 ; i++){
        if (i == desPiecesJoueur.lesLignesVides[compteur]){
            desPiecesJoueur.unePiece[compteur] = desPiecesJoueur.lesLignesStringJoueur[i + 1];
            if (desPiecesJoueur.lesLargeursPiecesJoueur[i + 1] < desPiecesJoueur.lesLargeursMaxPiecesJoueur[compteur]){
                for (int u = desPiecesJoueur.lesLargeursPiecesJoueur[i + 1] ; u != desPiecesJoueur.lesLargeursMaxPiecesJoueur[compteur] ; u++){
                    desPiecesJoueur.unePiece[compteur] = desPiecesJoueur.unePiece[compteur] + " ";
                }
            }
            compteur++;
        }else if (i + 1 != desPiecesJoueur.lesLignesVides[compteur]){
            desPiecesJoueur.unePiece[compteur] = desPiecesJoueur.unePiece[compteur] + desPiecesJoueur.lesLignesStringJoueur[i + 1];
            for (int u = desPiecesJoueur.lesLargeursPiecesJoueur[i + 1] ; u != desPiecesJoueur.lesLargeursMaxPiecesJoueur[compteur] ; u++){
                desPiecesJoueur.unePiece[compteur] = desPiecesJoueur.unePiece[compteur] + " ";
            }
        }
    }
}
