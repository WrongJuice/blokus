/**
 * \file afficheGrille.cpp
 * \brief Fonction d'affichage de la grille, lance la construction et il est nécessaire de lancer l'initialisation avant.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 */

#include <fonctions.h>

/**
 * \brief afficheGrille
 * \param unContenuConstant
 * \param unContenuGrille
 * \param desPiecesJoueur
 */
void afficheGrille(contenu unContenuConstant[] , contenu unContenuGrille[] , pieces desPiecesJoueur)
{
    for (int i = 0 ; i != 22 ; i++) //Ligne 1
    {
        changeCouleurEtEcrit(unContenuConstant , i);
    }
    std::cout << ' ';
    for (int i = 0 ; i != 21 ; i++){
        //on rajoutera ici une condition pour savoir si ou ou non on doit afficher le num
        std::cout << i  + 1;
        for (int u = 0 ; u != desPiecesJoueur.lesLargeursMaxPiecesJoueur[i] ; u++){
            std::cout << ' ';
        }
    }
    std::cout << std::endl;
    for (int i = 22 ; i != 44 ; i++) // Ligne 2
    {
        changeCouleurEtEcrit(unContenuConstant , i);
    }
    std::cout << ' ' << desPiecesJoueur.unePiece[0] << ' ';
    for (int i = 1 ; i != 21 ; i++){
        //on rajoutera ici une condition pour savoir si ou ou non on doit afficher le num
        for (int u = 0 ; u != desPiecesJoueur.lesLargeursMaxPiecesJoueur[i]/*ajouter + 1 pour lignes suivantes*/ ; u++){
            std::cout << desPiecesJoueur.unePiece[i][u];
        }
        std::cout << ' ';
    }
    for (int i = 0 ; i != 20 ; i++)
    {
        std::cout << std::endl;
        changeCouleurEtEcrit(unContenuConstant , 44 + i*2);
        for (int u = 0 ; u != 20 ; u++)
        {
            changeCouleurEtEcrit(unContenuGrille , u + i*20);
        }
        changeCouleurEtEcrit(unContenuConstant , 45 + i*2);
    }
    std::cout << std::endl;
    for (int i = 0 ; i != 22 ; i++)
    {
        changeCouleurEtEcrit(unContenuConstant , i + 84);
    }
    std::cout << std::endl;
    for (int i = 0 ; i != 63 ; i++){
        std::cout << i << " = " << desPiecesJoueur.lesLignesStringJoueur[i] << std::endl;
    }
}
