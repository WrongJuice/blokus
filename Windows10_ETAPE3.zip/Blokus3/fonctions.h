/**
 * \file fonctions.h
 * \brief header contenant les définitions des struct, enum et déclaratoins de fonctions.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 */


#ifndef FONCTIONS_H
#define FONCTIONS_H
#include <iostream>

/**
 * \brief The couleurs enum
 */
enum couleurs : int {Noir = 15 , Bleu = 153 , Vert = 170 , Rouge = 204 , Jaune = 238};

/**
 * \brief The contenu struct
 */
struct contenu {
    char leContenu;
    couleurs laCouleur = Noir;
};

/**
 * \brief The pieces struct
 */
struct pieces {
    std::string lesLignesStringJoueur[63] , unePiece[21];//une piece est un tableau par piece
    int lesLargeursPiecesJoueur[63] , lesHauteursPiecesJoueur[21] , lesLignesVides[20];
    int lesLargeursMaxPiecesJoueur[21] = {1 , 2 , 2 , 3 , 4 , 2 , 3 , 3 , 3 , 5 , 3 , 3 , 3 , 3 , 3 , 4 , 4 , 4 , 3 , 3 , 3};
    couleurs laCouleur = Noir;
};

/**
 * \brief initGrille
 * \param unContenuConstant
 * \param unContenuGrille
 */
void initGrille(contenu unContenuConstant[] , contenu unContenuGrille[]);

/**
 * \brief constructionGrille
 * \param unContenuGrille
 */
void constructionGrille(contenu unContenuGrille[]);

/**
 * \brief afficheGrille
 * \param unContenuConstant
 * \param unContenuGrille
 * \param unePiece
 */
void afficheGrille(contenu unContenuConstant[] , contenu unContenuGrille[] , pieces unePiece);

/**
 * \brief changeCouleurEtEcrit
 * \param unContenu
 * \param unIndice
 */
void changeCouleurEtEcrit(contenu unContenu[] , int unIndice);

/**
 * \brief changeCouleur
 * \param uneCouleur
 */
void changeCouleur(couleurs uneCouleur);

/**
 * \brief construitPieces
 * \param desPiecesJoueur
 */
void construitPieces(pieces &desPiecesJoueur);
#endif // FONCTIONS_H
