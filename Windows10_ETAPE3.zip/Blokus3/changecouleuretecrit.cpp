/**
 * \file changeCouleur.cpp
 * \brief Fonction qui change la couleur de la console et écrit le contenu associé.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 */


#include <fonctions.h>
#include <windows.h>

/**
 * \brief changeCouleurEtEcrit
 * \param unContenu
 * \param unIndice
 */
void changeCouleurEtEcrit(contenu unContenu[] , int unIndice)
{
    HANDLE H = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H , unContenu[unIndice].laCouleur);
    std::cout << unContenu[unIndice].leContenu;
    SetConsoleTextAttribute(H , Noir);
}
