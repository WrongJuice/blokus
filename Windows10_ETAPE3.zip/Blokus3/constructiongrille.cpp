/**
 * \file constructionGrille.cpp
 * \brief Construction de la grille en fonction des actions précedentes du joueur, plusieurs éxecutions nécessaires.
 * \version 0.1
 * \date 18 Novembre 2017
 */

#include <fonctions.h>

/**
 * \brief constructionGrille
 * \param unContenuGrille
 */
void constructionGrille(contenu unContenuGrille[])//Construction de la partie variable de la grille
{
    //Mon code qui reconstruira la fonction en fonction des actions précedentes du joueur
}
