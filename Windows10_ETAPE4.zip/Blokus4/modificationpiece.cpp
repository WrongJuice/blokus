/**
 * \file modificationPiece.cpp
 * \brief Fonction permettant de modifier les pièces.
 * \author Alfred.G
 * \version 1.0
 * \date 24 Novembre 2017
 */

#include <fonctions.h>
#include <QString>

/**
 * \brief modificationPiece
 * \param unePiece
 */
void modificationPiece(pieces unePiece[]){
    for (int numeroJoueur = 0 ; numeroJoueur != 1 ; numeroJoueur++){
        int leNumeroPlacement , leDebutPlacement = 0 , laPieceAModifier , laTailleSequence; bool ok , uneErreur = false;
        char laLettrePlacement;
        std::string laPieceAModifierStr , laSequence;
        std::cout << "Quelle piece modifier ? ";
        std::getline(std::cin , laPieceAModifierStr);
        laPieceAModifier = QString::fromStdString(laPieceAModifierStr).toInt(&ok);
        while (laPieceAModifier >= 22 or laPieceAModifier <= 0){
            std::cout << "Erreur: Veuillez rentrer un numero entre 1 et 21 ? ";
            std::getline(std::cin , laPieceAModifierStr);
            laPieceAModifier = QString::fromStdString(laPieceAModifierStr).toInt(&ok);
        }
        laPieceAModifier = laPieceAModifier - 1;
        std::cout << "Les sequences de modification possibles de cette piece sont les suivantes : \n"
                     "\"r\" = Rotation dans le sens horaire\n"
                     "\"h\" = Miroir selon l'axe horizontal\n"
                     "\"v\" = Miroir selon l'axe vertical\n"
                     "Il est possible d'effectuer plusieurs fois la meme sequence en placant le nombre de repetition(s) voulu\n"
                     "devant la sequence a repeter.\n"
                     "Les coordonnees du cote superieur gauche sont ajoutes a la fin de la sequence dans le format LETTREnumero\n"
                     "Si les sequences de modifications des pieces ne sont pas mentionne, seuls les placements seront appliquees !\n";
        bool laDecision = false , lePlacement = false;
        do{
            std::cout << "Quelle sequence effectuer ? (exemple: rr2hvP19) ";
            std::getline(std::cin , laSequence);
            laTailleSequence = laSequence.size();
            for (int i = 0 ; i != laTailleSequence and not uneErreur; i++){
                for (int u = 0 ; u != 20; u++){
                    laLettrePlacement = u + 65;
                    if (laSequence[i] == laLettrePlacement and leDebutPlacement == 0){
                        leDebutPlacement = i;
                        if (laTailleSequence - leDebutPlacement == 3){
                            lePlacement = true;
                            std::string leNumeroPlacementStr = {laSequence[i + 1] , laSequence[i + 2]};
                            leNumeroPlacement = QString::fromStdString(leNumeroPlacementStr).toInt(&ok);
                            if (leNumeroPlacement > 20 or leNumeroPlacement < 0){
                                std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
                                uneErreur = true;
                            }
                        }else if (laTailleSequence - leDebutPlacement == 2){
                            lePlacement = true;
                            leNumeroPlacement = laSequence[i + 1] - 48;
                            if (leNumeroPlacement > 20 or leNumeroPlacement < 0){
                                std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
                                uneErreur = true;
                            }
                        }else{
                            std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
                            uneErreur = true;
                        }
                    }
                }
            }
            if (not lePlacement and not uneErreur){
                std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
            }else if (not uneErreur){
                pieces uneCopie;
                for (int u = 0 ; u != leDebutPlacement ; u++){
                    uneCopie = unePiece[numeroJoueur];
                    int v , s;
                    switch (laSequence[u]) {
                    case 'r':
                        laDecision = true;
                        unePiece[numeroJoueur].lesHauteursPiecesJoueur[laPieceAModifier] = uneCopie.lesLargeursMaxPiecesJoueur[laPieceAModifier];
                        unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier] = uneCopie.lesHauteursPiecesJoueur[laPieceAModifier];
                        for (v = 0 ; v != unePiece[numeroJoueur].lesHauteursPiecesJoueur[laPieceAModifier]; v++){
                            for (s = 0 ; s != unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier] ; s++){
                                unePiece[numeroJoueur].unePiece[laPieceAModifier][unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier]*v+s] = uneCopie.unePiece[laPieceAModifier][unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier]*s+v];
                            }
                        }
                        uneCopie = unePiece[numeroJoueur];
                        for (v = 0 ; v != unePiece[numeroJoueur].lesHauteursPiecesJoueur[laPieceAModifier]; v++){
                            for (s = 0 ; s != unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier] ; s++){
                                unePiece[numeroJoueur].unePiece[laPieceAModifier][unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier]*v+s] = uneCopie.unePiece[laPieceAModifier][uneCopie.lesLargeursMaxPiecesJoueur[laPieceAModifier]*v-1+uneCopie.lesLargeursMaxPiecesJoueur[laPieceAModifier]-s];
                            }
                        }
                        break;
                    case 'h':
                        laDecision = true;
                        for (v = 0 ; v != unePiece[numeroJoueur].lesHauteursPiecesJoueur[laPieceAModifier]; v++){
                            for (s = 0 ; s != unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier] ; s++){
                                unePiece[numeroJoueur].unePiece[laPieceAModifier][unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier]*v+s] = uneCopie.unePiece[laPieceAModifier][uneCopie.lesLargeursMaxPiecesJoueur[laPieceAModifier]*v-1+uneCopie.lesLargeursMaxPiecesJoueur[laPieceAModifier]-s];
                            }
                        }
                        break;
                    case 'v':
                        laDecision = true;
                        for (v = 0 ; v != unePiece[numeroJoueur].lesHauteursPiecesJoueur[laPieceAModifier]; v++){
                            for (s = 0 ; s != unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier] ; s++){
                                unePiece[numeroJoueur].unePiece[laPieceAModifier][unePiece[numeroJoueur].lesLargeursMaxPiecesJoueur[laPieceAModifier]*v+s] = uneCopie.unePiece[laPieceAModifier][s + ((uneCopie.lesHauteursPiecesJoueur[laPieceAModifier]) - (1+v))*uneCopie.lesLargeursMaxPiecesJoueur[laPieceAModifier]];
                            }
                        }
                        break;
                    default:
                        std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
                        u = leDebutPlacement - 1;
                        break;
                    }
                }
            }
            lePlacement = false , uneErreur = false;
            leDebutPlacement = 0;
        }while(not laDecision);
        laDecision = true;
    }
}
