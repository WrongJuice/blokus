/**
 * \file main.cpp
 * \brief Fonction principal du projet de jeu de société Blockus.
 * \author Alfred.G
 * \version 1.0
 * \date 24 Novembre 2017
 */

#include <fonctions.h>

/**
 * \brief main
 * \return
 */
int main()
{
    contenu leContenuConstant[106];
    contenu leContenuGrille[400];
    pieces lesPiecesJoueurs[4];
    initGrille(leContenuConstant , leContenuGrille); //On initialise une fois certains caractères et les couleurs
    construitPieces(lesPiecesJoueurs , leContenuConstant , 0);
    afficheGrille(leContenuConstant , leContenuGrille , lesPiecesJoueurs[0]); //Construction et affichage de la grille
    modificationPiece(lesPiecesJoueurs);
    afficheGrille(leContenuConstant , leContenuGrille , lesPiecesJoueurs[0]);
}

//
