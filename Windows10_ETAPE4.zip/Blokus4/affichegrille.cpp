/**
 * \file afficheGrille.cpp
 * \brief Fonction d'affichage de la grille, lance la construction et il est nécessaire de lancer l'initialisation avant.
 * \author Alfred.G
 * \version 1.0
 * \date 24 Novembre 2017
 */

#include <fonctions.h>

/**
 * \brief afficheGrille
 * \param unContenuConstant
 * \param unContenuGrille
 * \param desPiecesJoueur
 */
void afficheGrille(contenu unContenuConstant[] , contenu unContenuGrille[] , pieces desPiecesJoueur)
{
    for (int i = 0 ; i != 22 ; i++) //Ligne 1
    {
        changeCouleurEtEcrit(unContenuConstant[i].leContenu , unContenuConstant[i].laCouleur);
    }
    std::cout << ' ';
    for (int i = 0 ; i != 21 ; i++){
        //on rajoutera ici une condition pour savoir si oui ou non on doit afficher le num
        std::cout << i + 1;
        for (int u = 0 ; u != (desPiecesJoueur.lesLargeursMaxPiecesJoueur[i] - i/9 + i/18); u++){
            std::cout << ' ';
        }
    }
    std::cout << std::endl;
    for (int i = 22 ; i != 44 ; i++) // Ligne 2
    {
        changeCouleurEtEcrit(unContenuConstant[i].leContenu , unContenuConstant[i].laCouleur);
    }
    std::cout << ' ';
    changeCouleurEtEcrit(desPiecesJoueur.unePiece[0][0] , desPiecesJoueur.laCouleur);
    for (int i = 1 ; i != 21 ; i++){
        //on rajoutera ici une condition pour savoir si ou ou non on doit afficher le num

        std::cout << ' ';
        for (int u = 0 ; u != desPiecesJoueur.lesLargeursMaxPiecesJoueur[i]/*ajouter + 1 pour lignes suivantes*/ ; u++){
            if (desPiecesJoueur.unePiece[i][u] == 'x'){
                changeCouleurEtEcrit(desPiecesJoueur.unePiece[i][u] , desPiecesJoueur.laCouleur);
            }else std::cout << desPiecesJoueur.unePiece[i][u];
        }
    }
    for (int i = 0 ; i != 20 ; i++)
    {
        std::cout << std::endl;
        changeCouleurEtEcrit(unContenuConstant[44 + i*2].leContenu , unContenuConstant[44 + i*2].laCouleur);
        for (int u = 0 ; u != 20 ; u++)
        {
            changeCouleurEtEcrit(unContenuGrille[u + i*20].leContenu , unContenuGrille[u + i*20].laCouleur);
        }
        changeCouleurEtEcrit(unContenuConstant[45 + i*2].leContenu , unContenuConstant[45 + i*2].laCouleur);
        for (int u = 0 ; u != 21 ; u++){
            std::cout << ' ';
            if (i + 1 < desPiecesJoueur.lesHauteursPiecesJoueur[u]){
                for (int v = 0 ; v != desPiecesJoueur.lesLargeursMaxPiecesJoueur[u] ; v++){
                    if (desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]] == 'x'){
                        changeCouleurEtEcrit(desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]] , desPiecesJoueur.laCouleur);
                    }else std::cout << desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]];
                }
            }else if (i <= 1){
                for (int v = 0 ; v != desPiecesJoueur.lesLargeursMaxPiecesJoueur[u] ; v++){
                    std::cout << ' ';
                }
            }
        }
    }
    std::cout << std::endl;
    for (int i = 0 ; i != 22 ; i++)
    {
        changeCouleurEtEcrit(unContenuConstant[i + 84].leContenu , unContenuConstant[i + 84].laCouleur);
    }
    std::cout << std::endl;
}
