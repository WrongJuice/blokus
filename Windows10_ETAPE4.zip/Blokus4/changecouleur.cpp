/**
 * \file changeCouleur.cpp
 * \brief Fonction qui change la couleur de la console.
 * \author Alfred.G
 * \version 1.0
 * \date 24 Novembre 2017
 */

#include <fonctions.h>
#include <windows.h>

/**
 * \brief changeCouleur
 * \param uneCouleur
 */
void changeCouleur(couleurs uneCouleur)
{
    HANDLE H = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H , uneCouleur);
}
