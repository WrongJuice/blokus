/**
 * \file construitpiece.cpp
 * \brief Construit les pièces.
 * \author Alfred.G
 * \version 1.0
 * \date 24 Novembre 2017
 */

#include <fonctions.h>
#include <fstream>

/**
 * \brief construitPieces
 * \param unePiece
 * \param unContenuConstant
 * \param unNumeroJoueur
 */
void construitPieces(pieces unePiece[] , contenu unContenuConstant[] , int unNumeroJoueur)
{
    std::ifstream leFichierPieces("pieces.txt" , std::ios::app); //On ouvre en lecture notes.txt et on le nomme leFichierPieces
    int compteur = 0 ;
    for (int i = 0 ; !leFichierPieces.eof() ; i++)
    {
        std::getline(leFichierPieces , unePiece[unNumeroJoueur].lesLignesStringJoueur[i]);
        unePiece[unNumeroJoueur].lesLargeursPiecesJoueur[i] = 0;
        if (unePiece[unNumeroJoueur].lesLignesStringJoueur[i] == unePiece[unNumeroJoueur].lesLignesStringJoueur[1]){
            unePiece[unNumeroJoueur].lesLignesVides[compteur] = i;
            compteur++;
        }else{
            unePiece[unNumeroJoueur].lesLargeursPiecesJoueur[i] = unePiece[unNumeroJoueur].lesLignesStringJoueur[i].size();
        }
    }
    compteur = 0;
    for (int i = 0 ; i != 62 ; i++){
        if (i == unePiece[unNumeroJoueur].lesLignesVides[compteur]){
            unePiece[unNumeroJoueur].unePiece[compteur + 1] = unePiece[unNumeroJoueur].lesLignesStringJoueur[i + 1];
            if (unePiece[unNumeroJoueur].lesLargeursPiecesJoueur[i + 1] < unePiece[unNumeroJoueur].lesLargeursMaxPiecesJoueur[compteur + 1]){
                for (int u = unePiece[unNumeroJoueur].lesLargeursPiecesJoueur[i + 1] ; u != unePiece[unNumeroJoueur].lesLargeursMaxPiecesJoueur[compteur + 1] ; u++){
                    unePiece[unNumeroJoueur].unePiece[compteur + 1] = unePiece[unNumeroJoueur].unePiece[compteur + 1] + " ";
                }
            }
            compteur++;
            unePiece[unNumeroJoueur].lesHauteursPiecesJoueur[compteur] = 1;
        }else if (i + 1 != unePiece[unNumeroJoueur].lesLignesVides[compteur]){
            unePiece[unNumeroJoueur].lesHauteursPiecesJoueur[compteur] = unePiece[unNumeroJoueur].lesHauteursPiecesJoueur[compteur] + 1;
            unePiece[unNumeroJoueur].unePiece[compteur] = unePiece[unNumeroJoueur].unePiece[compteur] + unePiece[unNumeroJoueur].lesLignesStringJoueur[i + 1];
            for (int u = unePiece[unNumeroJoueur].lesLargeursPiecesJoueur[i + 1] ; u != unePiece[unNumeroJoueur].lesLargeursMaxPiecesJoueur[compteur] ; u++){
                unePiece[unNumeroJoueur].unePiece[compteur] = unePiece[unNumeroJoueur].unePiece[compteur] + " ";
            }
        }else{
            unePiece[unNumeroJoueur].unePiece[0] = "x";
            unePiece[unNumeroJoueur].lesHauteursPiecesJoueur[0] = 1;
        }
    }
    switch (unNumeroJoueur) {
    case 3:
        unePiece[unNumeroJoueur].laCouleur = unContenuConstant[22].laCouleur;
        break;
    case 2:
        unePiece[unNumeroJoueur].laCouleur = unContenuConstant[43].laCouleur;
        break;
    case 0:
        unePiece[unNumeroJoueur].laCouleur = unContenuConstant[84].laCouleur;
        break;
    case 1:
        unePiece[unNumeroJoueur].laCouleur = unContenuConstant[105].laCouleur;
    }
}
