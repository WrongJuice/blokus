/**
 * \file initgrille.cpp
 * \brief Initialise la grille dans le tableau de caractères et les couleurs dans le tableau d'entiers.
 * \author Alfred.G
 * \version 1.0
 * \date 24 Novembre 2017
 */

#include <fonctions.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/**
 * \brief initGrille
 * \param unContenuConstant
 * \param unContenuGrille
 */
void initGrille(contenu unContenuConstant[] , contenu unContenuGrille[])
{
    for (int i = 1 ; i != 21 ; i++){//Première et deuxième ligne et colonne de gauche
        switch (i/10) {//Première ligne
        default: unContenuConstant[i].leContenu = '1';
                break;
        case 0: unContenuConstant[i].leContenu = ' ';
                break;
        case 2: unContenuConstant[i].leContenu = '2';
                break;
        }
        unContenuConstant[i + 22].leContenu = i%10 + 48;//Deuxième ligne
        unContenuConstant[42 + i*2].leContenu = i + 64;//Colonne de gauche
    }
    unContenuConstant[0].leContenu = ' ' , unContenuConstant[21].leContenu = ' ' , unContenuConstant[22].leContenu = ' ' , unContenuConstant[43].leContenu = ' ';
    for (int i = 0 ; i != 22 ; i++) //Construction de la ligne et la colonne "invisible"
    {
        unContenuConstant[43 + i*2].leContenu = ' ';
        unContenuConstant[84 + i].leContenu = ' ';
    }
    for (int i = 0 ; i != 400 ; i++)
    {
        unContenuGrille[i].leContenu = '.';
    }
    int uneCouleur[4];
    srand(time(NULL)); //Initialisation de rand
    switch (1) { //Switch nécessaire avec 3 boucles pour éviter que deux joueurs ou plus puissent avoir la même couleur
        case 1: uneCouleur[0] = (rand()%4) + 1;
        case 2:
            uneCouleur[1] = (rand()%4) + 1;
            while (uneCouleur[1] == uneCouleur[0]) //On reboucle jusqu'à obtenir un chiffre différent du précedent
            {
                uneCouleur[1] = (rand()%4) + 1;;
            }
        case 3:
            uneCouleur[2] = (rand()%4) + 1;;
            while (uneCouleur[2] == uneCouleur[1] or uneCouleur[2] == uneCouleur[0]) //différent du précedent et du premier
            {
                uneCouleur[2] = (rand()%4) + 1;
            }
        case 4:
            uneCouleur[3] = (rand()%4) + 1;
            while (uneCouleur[3] == uneCouleur[2] or uneCouleur[3] == uneCouleur[1] or uneCouleur[3] == uneCouleur[0]) //différent des trois premiers
            {
                uneCouleur[3] = (rand()%4) + 1;
            }
        }
    couleurs lesJoueursPremiereCase[4];
    for (int i = 0 ; i != 4 ; ++i) //Attribution d'une couleur en fonction du chiffre attribué plus haut
    {
        switch (uneCouleur[i]) {
        case 1: lesJoueursPremiereCase[i] = Vert;
            break;
        case 2: lesJoueursPremiereCase[i] = Jaune;
            break;
        case 3: lesJoueursPremiereCase[i] = Bleu;
            break;
        case 4: lesJoueursPremiereCase[i] = Rouge;
            break;
        }
    }
    unContenuConstant[22].laCouleur = lesJoueursPremiereCase[0];
    unContenuConstant[43].laCouleur = lesJoueursPremiereCase[1];
    unContenuConstant[84].laCouleur = lesJoueursPremiereCase[2];
    unContenuConstant[105].laCouleur = lesJoueursPremiereCase[3];
}
