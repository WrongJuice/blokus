/**
 * \file construitGrille.cpp
 * \brief Construit la grille en fonction des actions du joueur.
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>


/**
 * \brief construitGrille
 * \param unSetPieces
 * \param unContenuScene
 * \param desActions
 * \param unJoueurActif
 */
void construitGrille(pieces unSetPieces[] , contenu unContenuScene[] , action desActions[] , int unJoueurActif)
{
    int laLettrePlacement = desActions[unJoueurActif].laLettrePlacement - 65; //Obtention de la ligne de placement
    for (int c = 0 ; c != unSetPieces[unJoueurActif].lesHauteursPiecesJoueur[desActions[unJoueurActif].laPieceAModifier]; c++){ //Injection de la pièce dans le contenu de la grille
        for (int i = 0 ; i != unSetPieces[unJoueurActif].lesLargeursMaxPiecesJoueur[desActions[unJoueurActif].laPieceAModifier] ; i++){
            unContenuScene[44 + (laLettrePlacement + c)*22 + desActions[unJoueurActif].leNumeroPlacement + 1 + i].leContenu = unSetPieces[unJoueurActif].lesPieces[desActions[unJoueurActif].laPieceAModifier][i + c*unSetPieces[unJoueurActif].lesLargeursMaxPiecesJoueur[desActions[unJoueurActif].laPieceAModifier]]; //On injecte ici
            if (unContenuScene[44 + (laLettrePlacement + c)*22 + desActions[unJoueurActif].leNumeroPlacement + 1 + i].leContenu == ' '){ //Si on a injecté un espace dans la grille alors...
                unContenuScene[44 + (laLettrePlacement + c)*22 + desActions[unJoueurActif].leNumeroPlacement + 1 + i].leContenu = '.'; //...On ré-affiche un point !
            }else{
                unContenuScene[44 + (laLettrePlacement + c)*22 + desActions[unJoueurActif].leNumeroPlacement + 1 + i].laCouleur = unSetPieces[unJoueurActif].laCouleur; //Sinon on met la couleur de la pièce au bon emplacement
            }
        }
    }
}
