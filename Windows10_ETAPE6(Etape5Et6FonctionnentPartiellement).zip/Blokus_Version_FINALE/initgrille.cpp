/**
 * \file initGrille.cpp
 * \brief Initialise la grille dans le tableau de caractères et les couleurs.
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


/**
 * \brief initGrille
 * \param unContenuScene
 */
void initGrille(contenu unContenuScene[] )
{
    int uneCouleur[4]; //Tableau de chiffres entre 1 et 4 permettant d'associer une couleur
    couleurs uneVraieCouleur[4];
    for (int i = 45 ; i != 483 ; i++) //Grille de points
    {
        unContenuScene[i].leContenu = '.';
    }
    for (int i = 0 ; i != 21 ; i++){ //Première et deuxième ligne et colonne de gauche et de droite
        switch (i/10) { //Première ligne
        case 0: unContenuScene[i].leContenu = ' ';
            break;
        case 1: unContenuScene[i].leContenu = '1';
            break;
        case 2: unContenuScene[i].leContenu = '2';
            break;
        }
        unContenuScene[i + 22].leContenu = i%10 + 48; //Deuxième ligne
        unContenuScene[44 + i*22].leContenu = i + 65; //Colonne de gauche
        unContenuScene[21 + i*22].leContenu = ' '; //Espaces à droite du tableau
    }
    unContenuScene[21].leContenu = ' ' , unContenuScene[22].leContenu = ' ' , unContenuScene[43].leContenu = ' ';
    for (int i = 0 ; i != 23 ; i++) //Construction de la ligne et la colonne "invisible"
    {
        unContenuScene[483 + i].leContenu = ' ';
    }
    srand(time(NULL)); //Initialisation de rand
    switch (1) { //Switch nécessaire avec 3 boucles pour éviter que deux joueurs ou plus puissent avoir la même couleur
    case 1: uneCouleur[0] = (rand()%4) + 1;
    case 2:
        uneCouleur[1] = (rand()%4) + 1;
        while (uneCouleur[1] == uneCouleur[0]) //On reboucle jusqu'à obtenir un chiffre différent du précedent
        {
            uneCouleur[1] = (rand()%4) + 1;;
        }
    case 3:
        uneCouleur[2] = (rand()%4) + 1;;
        while (uneCouleur[2] == uneCouleur[1] or uneCouleur[2] == uneCouleur[0]) //différent du précedent et du premier
        {
            uneCouleur[2] = (rand()%4) + 1;
        }
    case 4:
        uneCouleur[3] = (rand()%4) + 1;
        while (uneCouleur[3] == uneCouleur[2] or uneCouleur[3] == uneCouleur[1] or uneCouleur[3] == uneCouleur[0]) //différent des trois premiers
        {
            uneCouleur[3] = (rand()%4) + 1;
        }
    }
    for (int i = 0 ; i != 4 ; ++i) //Attribution d'une couleur en fonction du chiffre attribué plus haut
    {
        switch (uneCouleur[i]) {
        case 1: uneVraieCouleur[i] = Bleu;
            break;
        case 2: uneVraieCouleur[i] = Vert;
            break;
        case 3: uneVraieCouleur[i] = Rouge;
            break;
        case 4: uneVraieCouleur[i] = Jaune;
            break;
        }
        switch (i) {
        case 0: unContenuScene[22].laCouleur = uneVraieCouleur[i];
            break;
        case 1: unContenuScene[43].laCouleur = uneVraieCouleur[i];
            break;
        case 2: unContenuScene[484].laCouleur = uneVraieCouleur[i];
            break;
        case 3: unContenuScene[505].laCouleur = uneVraieCouleur[i];
            break;
        }
    }
}
