/**
 * \file construitPieces.cpp
 * \brief Construit les pièces en fonction du nombre de joueurs.
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>
#include <fstream>


/**
 * \brief construitPieces
 * \param unSetPieces
 * \param unContenuScene
 * \param unNbJoueurs
 */
void construitPieces(pieces unSetPieces[] , contenu unContenuScene[], int unNbJoueurs)
{
    //ON INJECTE LES COULEUR DES PIECES DES JOUEURS PAR RAPPORT AUX COULEURS DES ANGLES DE LA GRILLE
    unSetPieces[0].laCouleur = unContenuScene[22].laCouleur;
    unSetPieces[1].laCouleur = unContenuScene[43].laCouleur;
    unSetPieces[2].laCouleur = unContenuScene[484].laCouleur;
    unSetPieces[3].laCouleur = unContenuScene[505].laCouleur;
    for (int n = 0 ; n != unNbJoueurs ; n++){
        std::ifstream leFichierPieces("pieces.txt" , std::ios::app); //On ouvre en lecture notes.txt et on le nomme leFichierPieces
        int compteur = 0 ;
        for (int i = 0 ; !leFichierPieces.eof() ; i++) //Tant que l'on est pas au bout du fihier
        {
            std::getline(leFichierPieces , unSetPieces[n].lesLignesStringJoueur[i]); //On place toutes les lignes dans un tableau
            unSetPieces[n].lesLargeursPiecesJoueur[i] = 0; //Initialisation
            if (unSetPieces[n].lesLignesStringJoueur[i] == unSetPieces[n].lesLignesStringJoueur[1]){ //On note et on compte les lignes vides
                unSetPieces[n].lesLignesVides[compteur] = i;
                compteur++;
            }else{
                unSetPieces[n].lesLargeursPiecesJoueur[i] = unSetPieces[n].lesLignesStringJoueur[i].size(); //On note les largeurs de chaque lignes non vides
            }
        }
        leFichierPieces.close(); //Fermeture fichier de pièces
        compteur = 0;
        for (int i = 0 ; i != 62 ; i++){
            if (i == unSetPieces[n].lesLignesVides[compteur]){ //Détection d'une nouvelle pièce
                unSetPieces[n].lesPieces[compteur + 1] = unSetPieces[n].lesLignesStringJoueur[i + 1]; //Injection de la première ligne de caractère dans la pièce
                if (unSetPieces[n].lesLargeursPiecesJoueur[i + 1] < unSetPieces[n].lesLargeursMaxPiecesJoueur[compteur + 1]){ //Doit on ajouter des caractères de vide ?
                    for (int u = unSetPieces[n].lesLargeursPiecesJoueur[i + 1] ; u != unSetPieces[n].lesLargeursMaxPiecesJoueur[compteur + 1] ; u++){
                        unSetPieces[n].lesPieces[compteur + 1] = unSetPieces[n].lesPieces[compteur + 1] + " "; //Si oui ajoutons les ici
                    }
                }
                compteur++;
                unSetPieces[n].lesHauteursPiecesJoueur[compteur] = 1; //Initialisation (On est sur que la hauteur est d'au moins 1)
            }else if (i + 1 != unSetPieces[n].lesLignesVides[compteur]){
                unSetPieces[n].lesHauteursPiecesJoueur[compteur] = unSetPieces[n].lesHauteursPiecesJoueur[compteur] + 1; //Augmentation de la hauteur
                unSetPieces[n].lesPieces[compteur] = unSetPieces[n].lesPieces[compteur] + unSetPieces[n].lesLignesStringJoueur[i + 1]; //Ajout d'une nouvelle ligne de la pièce
                for (int u = unSetPieces[n].lesLargeursPiecesJoueur[i + 1] ; u != unSetPieces[n].lesLargeursMaxPiecesJoueur[compteur] ; u++){ //Doit on ajouter un espace ?
                    unSetPieces[n].lesPieces[compteur] = unSetPieces[n].lesPieces[compteur] + " "; //Si oui, ajoutons le
                }
            }else{ //Pièce 1 = injection manuelle
                unSetPieces[n].lesPieces[0] = "x";
                unSetPieces[n].lesHauteursPiecesJoueur[0] = 1;
            }
        }
        for (int i = 0 ; i != 5 ; i++){ //Initialisation
            unSetPieces[n].lesHauteursMaxParTailles[i] = 0;
        }
        for (int i = 0 ; i != 21 ; i++){
            unSetPieces[n].lesPlacements[i] = false; // Ne sera pas utilisé, permet de savoir si la pièce à été placé
            unSetPieces[n].lesTailles[i] = 0;
            int taillePiece = unSetPieces[n].lesPieces[i].size();
            for (int u = 0 ; u != taillePiece ; u++){ //Calcul de la taille de la pièce
                if (unSetPieces[n].lesPieces[i][u] == 'x'){
                    unSetPieces[n].lesTailles[i]++;
                }
            }
            if (unSetPieces[n].lesHauteursMaxParTailles[unSetPieces[n].lesTailles[i] - 1] < unSetPieces[n].lesHauteursPiecesJoueur[i]){ //Calcul hauteur maximum des pièce par leur taille
                unSetPieces[n].lesHauteursMaxParTailles[unSetPieces[n].lesTailles[i] - 1] = unSetPieces[n].lesHauteursPiecesJoueur[i];
            }
        }
    }
}
