/**
 * \file afficheNumerosPieces.cpp
 * \brief Fonction d'affichage des numéros des pièces
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>


/**
 * \brief afficheNumerosPieces
 * \param unSetPieces
 * \param uneTaille
 */
void afficheNumerosPieces(pieces unSetPieces , int uneTaille){
    for (int i = 0 ; i != 21 ; i++){
        if (unSetPieces.lesTailles[i] == uneTaille){ //Si la pièce est de la bonne taille on peut afficher son numéro
            std::cout << i + 1; //Les numéros des pièces
            for (int u = 0 ; u != (unSetPieces.lesLargeursMaxPiecesJoueur[i] - i/9 + i/18); u++){ // i/18 pour éviter que i/9 soit égal à 2
                std::cout << ' '; //Les espaces qui séparent une pièce de l'autre
            }
        }
    }
}
