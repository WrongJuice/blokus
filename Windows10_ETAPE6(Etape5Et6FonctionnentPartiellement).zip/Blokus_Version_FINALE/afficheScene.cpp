/**
 * \file afficheScene.cpp
 * \brief Fonctions d'affichage de la scène (grille + pièces)
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>


/**
 * \brief afficheScene
 * \param unContenuScene
 * \param unSetPieces
 * \param unJoueurActif
 * \param unNomJoueur
 */
void afficheScene(contenu unContenuScene[] , pieces unSetPieces[] , int unJoueurActif , std::string unNomJoueur)
{
    system("cls"); //Clearing de la console
    bool lesTailles[5] , lesNumeros[5]; int laTailleAAfficher ; int leNumeroDeLigne = 0;
    for (int i = 0 ; i != 5 ; i++){ //Initialisation de variables
        lesTailles[i] = false;
        lesNumeros[i] = false;
    }
    for (int i = 0 ; i != 23 ; i++){ //La scène mesure 23 lignes
        for (int j = 0 ; j != 22 ; j++){ //La "grille" (partie gauche de la scène) mesure 22 char de large
            changeCouleurEtEcrit(unContenuScene[j + i*22].leContenu , unContenuScene[j + i*22].laCouleur); //Affihage de la partie gauche de la scène
        }
        for (int j = 0 ; j != 5 ; j++){ //Calcul de la taille à afficher (1 , 2 , 3 , 4 ou 5 'x')
            if (not lesTailles[j]){
                laTailleAAfficher = j + 1;
            }
        }
        std::cout << ' ';
        if (i == 0){ //Si il ne l'est pas déjà, affichage du nom du joueur
            std::cout << "Nom du Joueur : " << unNomJoueur;
        }else {
            if (not lesNumeros[laTailleAAfficher - 1]){ //Si ils ne le sont pas déjà, affichage des numéros
                afficheNumerosPieces(unSetPieces[unJoueurActif] , laTailleAAfficher);
                lesNumeros[laTailleAAfficher - 1] = true; //Les numéros ont bien été affichés
            }else{
                if (not lesTailles[0]){ //Pour éviter d'afficher indéfiniment la pièce 1
                    for (int j = 0 ; j != 21 ; j++){
                        if (unSetPieces[unJoueurActif].lesTailles[j] == laTailleAAfficher){ //Si la pièce est de la bonne taille
                            for (int k = 0 ; k != unSetPieces[unJoueurActif].lesLargeursMaxPiecesJoueur[j] ; k++){ //Affichage de la pièce
                                if (unSetPieces[unJoueurActif].lesHauteursPiecesJoueur[j] < leNumeroDeLigne){ //Si la pièce a déjà été complètement été affichée
                                    std::cout << ' ';
                                }else{
                                    if (unSetPieces[unJoueurActif].lesPieces[j][k + (unSetPieces[unJoueurActif].lesLargeursMaxPiecesJoueur[j]*leNumeroDeLigne)] == 'x'){ //Affichage de la pièce
                                        changeCouleurEtEcrit(unSetPieces[unJoueurActif].lesPieces[j][k + (unSetPieces[unJoueurActif].lesLargeursMaxPiecesJoueur[j]*leNumeroDeLigne)] , unSetPieces[unJoueurActif].laCouleur);
                                    }else{
                                        std::cout << ' '; //Pour ne pas afficher le 'x' et la couleur on affiche un espace
                                    }
                                }
                            }
                            std::cout << ' '; //L'espace entre chaque pièce
                        }
                    }
                    leNumeroDeLigne = leNumeroDeLigne + 1; //Le numéro de ligne des pièce d'une taille
                }
            }
            if (leNumeroDeLigne == unSetPieces[unJoueurActif].lesHauteursMaxParTailles[laTailleAAfficher - 1]){ //Test pour passer à une autre taille
                lesTailles[laTailleAAfficher - 1] = true;
                leNumeroDeLigne = 0;
            }
            //ICI
        }/*
        unSetPieces[unJoueurActif].lesHauteursMaxParTailles[laTailleAAfficher - 1]--;
        if (unSetPieces[unJoueurActif].lesHauteursMaxParTailles[laTailleAAfficher] == -1){
            lesTailles[laTailleAAfficher] = true;
        }else{
            for (int j = 0 ; j != 21 ; j++){
                if (unSetPieces[unJoueurActif].lesTailles[j] == laTailleAAfficher){
                    if (unSetPieces[unJoueurActif].lesHauteursMaxParTailles[laTailleAAfficher - 1] == uneCopieHauteursMax[laTailleAAfficher - 1]){
                        unSetPieces[unJoueurActif].lesHauteursMaxParTailles[laTailleAAfficher - 1]++;
                        afficheNumerosPieces(unSetPieces[unJoueurActif] , laTailleAAfficher);
                    }else if((uneCopieHauteursMax[laTailleAAfficher - 1] - (unSetPieces[unJoueurActif].lesHauteursMaxParTailles[laTailleAAfficher - 1] + 1)) == unSetPieces[unJoueurActif].lesHauteursPiecesJoueur[j]){
                        for (int l = 0 ; l != unSetPieces[unJoueurActif].lesLargeursMaxPiecesJoueur[j] ; l++){
                            std::cout << ' ';
                        }
                    }else{
                        for (int l = 0 ; l != unSetPieces[unJoueurActif].lesLargeursMaxPiecesJoueur[j] ; l++){
                            changeCouleurEtEcrit(unSetPieces[unJoueurActif].lesPieces[j][l + unSetPieces[unJoueurActif].lesLargeursMaxPiecesJoueur[j]*(uneCopieHauteursMax[laTailleAAfficher - 1] - (unSetPieces[unJoueurActif].lesHauteursMaxParTailles[laTailleAAfficher - 1] + 1))] , unSetPieces[unJoueurActif].laCouleur);
                        }
                    }
                }
                std::cout << ' ';
            }
        }
        std::cout << std::endl;
    }
    for (int i = 0 ; i != 5 ; i++){
        unSetPieces[unJoueurActif].lesHauteursMaxParTailles[i] = uneCopieHauteursMax[i];
    }*/
        std::cout << std::endl; //Passage à une autre ligne
    }
}


//ANCIENNE VERSION DE LA FONCTION DAFFICHAGE
//FONCTIONNE POUR LE SOLO SI ON A DEUX CONTENUS:
//-UN CONTENU CONSTANT (2 PREMIERES LIGNES + COLONNE DE GAUCHE + COLONNE DE DROITE + DERNIERE LIGNE)
//-UN CONTENU CONTENANT LA GRILLE (TABLEAU DE 20*20)
//FONCTIONS ABANDONNE CAR MANQUE DOPTIMISATION + TROP COMPLIQUE
/*for (int i = 0 ; i != 22 ; i++){
        {
            changeCouleurEtEcrit(unContenuConstant[i].leContenu , unContenuConstant[i].laCouleur);
        }
        std::cout << ' ';
        //On ajouteras le Nom du joueur ici
        afficheNumerosPieces(desPiecesJoueur);//Numéros des pièces (devras être déplacé au moment de l'ajout des noms des joueurs)
        std::cout << std::endl;
    }
    for (int j = 0 ; j != 23 ; j++){ //Plateau = 23 lignes
        if (j == 0){//Détection Ligne 0
            for (int i = 0 ; i != 22 ; i++) //Ligne 0
            {
                changeCouleurEtEcrit(unContenuConstant[i].leContenu , unContenuConstant[i].laCouleur);
            }
            std::cout << ' ';
            //On ajouteras le Nom du joueur ici
            afficheNumerosPieces(desPiecesJoueur);//Numéros des pièces (devras être déplacé au moment de l'ajout des noms des joueurs)
            std::cout << std::endl;
        }else if (j == 1){
            for (int i = 22 ; i != 44 ; i++) // Ligne 1
            {
                changeCouleurEtEcrit(unContenuConstant[i].leContenu , unContenuConstant[i].laCouleur);//Numéros
            }
            //DEBUT D'AFFICHAGE DES PIECES
            for (int i = 0 ; i != 21 ; i++){
                //on rajoutera ici une condition pour savoir si ou ou non on doit afficher le numéro
                std::cout << ' ';
                for (int u = 0 ; u != desPiecesJoueur.lesLargeursMaxPiecesJoueur[i]; u++){
                    if (desPiecesJoueur.unePiece[i][u] == 'x'){
                        changeCouleurEtEcrit(desPiecesJoueur.unePiece[i][u] , desPiecesJoueur.laCouleur);
                    }else std::cout << desPiecesJoueur.unePiece[i][u];
                }
            }
        }else {
            for (int i = 0 ; i != 20 ; i++)
            {
                std::cout << std::endl;
                changeCouleurEtEcrit(unContenuConstant[44 + i*2].leContenu , unContenuConstant[44 + i*2].laCouleur);
                for (int u = 0 ; u != 20 ; u++)
                {
                    changeCouleurEtEcrit(unContenuGrille[u + i*20].leContenu , unContenuGrille[u + i*20].laCouleur);
                }
                changeCouleurEtEcrit(unContenuConstant[45 + i*2].leContenu , unContenuConstant[45 + i*2].laCouleur);
                for (int u = 0 ; u != 21 ; u++){
                    std::cout << ' ';
                    if (i + 1 < desPiecesJoueur.lesHauteursPiecesJoueur[u]){
                        for (int v = 0 ; v != desPiecesJoueur.lesLargeursMaxPiecesJoueur[u] ; v++){
                            if (desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]] == 'x'){
                                changeCouleurEtEcrit(desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]] , desPiecesJoueur.laCouleur);
                            }else std::cout << desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]];
                        }
                    }else if (i <= 1){
                        for (int v = 0 ; v != desPiecesJoueur.lesLargeursMaxPiecesJoueur[u] ; v++){
                            std::cout << ' ';
                        }
                    }
                }
            }
        }
    }


    for (int i = 0 ; i != 20 ; i++)
    {
        std::cout << std::endl;
        changeCouleurEtEcrit(unContenuConstant[44 + i*2].leContenu , unContenuConstant[44 + i*2].laCouleur);
        for (int u = 0 ; u != 20 ; u++)
        {
            changeCouleurEtEcrit(unContenuGrille[u + i*20].leContenu , unContenuGrille[u + i*20].laCouleur);
        }
        changeCouleurEtEcrit(unContenuConstant[45 + i*2].leContenu , unContenuConstant[45 + i*2].laCouleur);
        for (int u = 0 ; u != 21 ; u++){
            std::cout << ' ';
            if (i + 1 < desPiecesJoueur.lesHauteursPiecesJoueur[u]){
                for (int v = 0 ; v != desPiecesJoueur.lesLargeursMaxPiecesJoueur[u] ; v++){
                    if (desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]] == 'x'){
                        changeCouleurEtEcrit(desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]] , desPiecesJoueur.laCouleur);
                    }else std::cout << desPiecesJoueur.unePiece[u][v + (i + 1)*desPiecesJoueur.lesLargeursMaxPiecesJoueur[u]];
                }
            }else if (i <= 1){
                for (int v = 0 ; v != desPiecesJoueur.lesLargeursMaxPiecesJoueur[u] ; v++){
                    std::cout << ' ';
                }
            }
        }
    }
    std::cout << std::endl;
    for (int i = 0 ; i != 22 ; i++)
    {
        changeCouleurEtEcrit(unContenuConstant[i + 84].leContenu , unContenuConstant[i + 84].laCouleur);
    }
    std::cout << std::endl;*/
