/**
 * \file changeCouleurEtEcrit.cpp
 * \brief Fonction qui change la couleur de la console et écrit le contenu associé.
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>
#include <windows.h>


/**
 * \brief changeCouleurEtEcrit
 * \param unContenu
 * \param uneCouleur
 */
void changeCouleurEtEcrit(char unContenu, couleurs uneCouleur)
{
    HANDLE H = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H , uneCouleur);
    std::cout << unContenu;
    SetConsoleTextAttribute(H , Noir); //On remet la couleur par défaut en Noir
}
