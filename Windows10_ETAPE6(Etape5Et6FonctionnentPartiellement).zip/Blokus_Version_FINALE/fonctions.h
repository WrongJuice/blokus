/**
 * \file fonctions.h
 * \brief Déclaration des fonctions, définitions des structures et des enumérations.
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#ifndef FONCTIONS_H
#define FONCTIONS_H
#include <iostream>

/**
 * \brief The couleurs enum
 */
enum couleurs : int {Noir = 15 , Bleu = 153 , Vert = 170 , Rouge = 204 , Jaune = 238}; //Les couleurs du jeu

/**
 * \brief The contenu struct
 */
struct contenu { //Le contenu de la partie de gauche de la scène
    char leContenu;
    couleurs laCouleur = Noir;
};

/**
 * \brief The pieces struct
 */
struct pieces { //Le contenu de la partie de droite de la scène (les pièces)
    std::string lesLignesStringJoueur[63] , lesPieces[21];//une piece est un tableau par piece
    bool lesPlacements[21];
    int lesLargeursPiecesJoueur[63] , lesHauteursPiecesJoueur[21] , lesLignesVides[20] , lesTailles[21] , lesHauteursMaxParTailles[5];
    int lesLargeursMaxPiecesJoueur[21] = {1 , 2 , 2 , 3 , 4 , 2 , 3 , 3 , 3 , 5 , 3 , 3 , 3 , 3 , 3 , 4 , 4 , 4 , 3 , 3 , 3};//Je peux le faire très simplement avec une boucle
    couleurs laCouleur = Noir;
};

/**
 * \brief The action struct
 */
struct action { //Les actions décidés par un joueur
    int leNumeroPlacement , laPieceAModifier;
    char laLettrePlacement;
};

/**
 * \brief initGrille
 * \param unContenuScene
 */
void initGrille(contenu unContenuScene[]);

/**
 * \brief afficheScene
 * \param unContenuScene
 * \param unSetPieces
 * \param unJoueurActif
 * \param unNomJoueur
 */
void afficheScene(contenu unContenuScene[] , pieces unSetPieces[] , int unJoueurActif, std::string unNomJoueur);

/**
 * \brief changeCouleurEtEcrit
 * \param unContenu
 * \param uneCouleur
 */
void changeCouleurEtEcrit(char unContenu, couleurs uneCouleur);

/**
 * \brief construitPieces
 * \param unSetPieces
 * \param unContenuScene
 * \param unNbJoueurs
 */
void construitPieces(pieces unSetPieces[] , contenu unContenuScene[] , int unNbJoueurs);

/**
 * \brief modificationPiece
 * \param unSetPieces
 * \param desActions
 * \param unNbJoueurs
 * \param unContenuScene
 * \param desNomsJoueurs
 */
void modificationPiece(pieces unSetPieces[], action desActions[], int unNbJoueurs , contenu unContenuScene[], std::string desNomsJoueurs[]);

/**
 * \brief afficheNumerosPieces
 * \param unSetPieces
 * \param uneTaille
 */
void afficheNumerosPieces(pieces unSetPieces, int uneTaille);

/**
 * \brief identiteJoueurs
 * \param unNbJoueurs
 * \param desNomsJoueurs
 */
void identiteJoueurs(int &unNbJoueurs , std::string desNomsJoueurs[]);

/**
 * \brief construitGrille
 * \param unSetPieces
 * \param unContenuScene
 * \param desActions
 * \param unJoueurActif
 */
void construitGrille(pieces unSetPieces[] , contenu unContenuScene[] , action desActions[], int unJoueurActif);
#endif // FONCTIONS_H
