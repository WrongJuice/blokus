/**
 * \file constructionGrille.cpp
 * \brief Construit la grille.
 * \author Alfred.G
 * \version 0.1
 * \date 18 Novembre 2017
 *
 * Construction de la grille en fonction des actions précedentes du joueur, plusieurs éxecutions nécessaires
 *
 */

#include <fonctions.h>

void constructionGrille(contenu unContenuGrille[])//Construction de la partie variable de la grille
{
    //Mon code qui reconstruira la fonction en fonction des actions précedentes du joueur
}
