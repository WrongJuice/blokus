/**
 * \file modificationPiece.cpp
 * \brief Fonction de modification des pièces
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>
#include <QString>


/**
 * \brief modificationPiece
 * \param unSetPieces
 * \param desActions
 * \param unNbJoueurs
 * \param unContenuScene
 * \param desNomsJoueurs
 */
void modificationPiece(pieces unSetPieces[] , action desActions[] , int unNbJoueurs , contenu unContenuScene[] , std::string desNomsJoueurs[]){
    for (int numeroJoueur = 0 ; numeroJoueur != unNbJoueurs ; numeroJoueur++){
        afficheScene(unContenuScene , unSetPieces , numeroJoueur , desNomsJoueurs[numeroJoueur]); //Construction et affichage de la grille
        int leDebutPlacement = 0 , laTailleSequence , leNbChiffre = 0; bool ok , uneErreur = false , laDecision = false , lePlacement = false , laErreurPieceModif = false , laLettrePlacement = false;
        std::string unePieceAModifierStr , laSequence;
        std::cout << "Entrez la piece a placer ou/et a modifier, suivie de sa sequence de modification !\n"
                     "Les sequences de modification possibles sont les suivantes : \n"
                     "\"r\" = Rotation dans le sens horaire\n"
                     "\"h\" = Miroir selon l'axe horizontal\n"
                     "\"v\" = Miroir selon l'axe vertical\n"
                     "Il est possible d'effectuer plusieurs fois la meme sequence en placant le nombre de repetition(s) voulu\n"
                     "devant la sequence a repeter.\n"
                     "Les coordonnees du cote superieur gauche sont ajoutes a la fin de la sequence dans le format LETTREnumero\n"
                     "Si les sequences de modifications des pieces ne sont pas mentionne, seuls les placements seront appliquees !\n";
        do{
            do{
                std::cout << "Quelle sequence effectuer ? (exemple: 5rrhvP12) "; //J'ai adopté une structure de sequnce différent de celle proposé dans le guide, je ne sais pas si elle plus simple ou plus difficile, j'ai fais ça parce que les instructions ne me parraissaient pas clair et cela fonctionne aussi bien donc je n'ai pas changé
                std::getline(std::cin , laSequence);
                laTailleSequence = laSequence.size();
                leNbChiffre = 0;
                if (laTailleSequence > 2){
                    for (int i = 0 ; i != laTailleSequence - 2 ; i++){ //On compte le nombre de chiffre de sélection de la pièce
                        if (laSequence[i] >= 48 and laSequence[i] <= 57){
                            leNbChiffre++;
                        }
                    }
                }
                unePieceAModifierStr = "  "; //On initialise un string vide au cas ou il n'y ai qu'un chiffre (donc un char) pour éviter des problèmes
                for (int i = 0  ; i != leNbChiffre ; i++){
                    unePieceAModifierStr[i] = laSequence[i];
                }
                desActions[numeroJoueur].laPieceAModifier = QString::fromStdString(unePieceAModifierStr).toInt(&ok) - 1; //On prend la pièce à modifier en string et on la met en int, on fait -1 car la premier indice de pièce n'est pas 1 mais 0 (indices sont décalés par rapport aux numéros affichés)
                if (desActions[numeroJoueur].laPieceAModifier >= 22 or desActions[numeroJoueur].laPieceAModifier <= 0 or leNbChiffre <= 0 or leNbChiffre > 2){ //Si on a entré un nombre à plus de 2 chiffres ou moins d'un chiffre
                    std::cout << "Erreur: Veuillez rentrer un numero entre 1 et 21 ? ";
                    laErreurPieceModif = true;
                }else{
                    laErreurPieceModif = false;
                }
            }while(laErreurPieceModif); //On recommence cette partie tant qu'il y a une ou des erreurs
            for (int i = leNbChiffre - 1 ; i != laTailleSequence and not uneErreur and not laErreurPieceModif; i++){
                for (int u = 0 ; u != 20 ; u++){
                    if (not laLettrePlacement){ //Reboucle et devient toujours égal à 19 si l'on ajoute pas une condition
                        desActions[numeroJoueur].laLettrePlacement = u + 65;//Conversion en char
                    }
                    if (laSequence[i] == desActions[numeroJoueur].laLettrePlacement and leDebutPlacement == 0){ //Si la lettre est la bonne
                        leDebutPlacement = i; laLettrePlacement = true;
                        if (laTailleSequence - leDebutPlacement == 3){//Nombre du placement supérieur ou égal à 10
                            lePlacement = true;
                            std::string leNumeroPlacementStr = {laSequence[i + 1] , laSequence[i + 2]};
                            desActions[numeroJoueur].leNumeroPlacement= QString::fromStdString(leNumeroPlacementStr).toInt(&ok);
                            if (desActions[numeroJoueur].leNumeroPlacement > 20 or desActions[numeroJoueur].leNumeroPlacement< 0){ //Si en dehors de la grille
                                std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
                                uneErreur = true;
                            }
                        }else if (laTailleSequence - leDebutPlacement == 2){//Chiffre du placement inférieur à 10
                            lePlacement = true;
                            desActions[numeroJoueur].leNumeroPlacement= laSequence[i + 1] - 48;
                            if (desActions[numeroJoueur].leNumeroPlacement> 20 or desActions[numeroJoueur].leNumeroPlacement< 0){
                                std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
                                uneErreur = true;
                            }
                        }else{ //Pas de chiffre/nombre de placement...
                            std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
                            uneErreur = true;
                        }
                    }
                }
            }
            if (not lePlacement and not uneErreur){ //Si on a rien entré
                std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
            }else if (not uneErreur){
                if ((laTailleSequence - ((laTailleSequence - leDebutPlacement) + leNbChiffre)) == 0){ //Pas de placement
                    laDecision = true;
                }else{
                    pieces uneCopieSet;
                    for (int u = leNbChiffre ; u != leDebutPlacement ; u++){
                        uneCopieSet = unSetPieces[numeroJoueur]; //Permet d'appliquer les changements sur la pièce sans perdre des données
                        int v , s;
                        switch (laSequence[u]) {
                        case 'r': //ROTATION
                            laDecision = true;
                            unSetPieces[numeroJoueur].lesHauteursPiecesJoueur[desActions[numeroJoueur].laPieceAModifier] = uneCopieSet.lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]; //SUR CES DEUX LIGNES, ON INVERSE LA HAUTEUR ET LA LARGEUR DE LA PIECE POUR LA ROTATION
                            unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier] = uneCopieSet.lesHauteursPiecesJoueur[desActions[numeroJoueur].laPieceAModifier];
                            for (v = 0 ; v != unSetPieces[numeroJoueur].lesHauteursPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]; v++){
                                for (s = 0 ; s != unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier] ; s++){
                                    unSetPieces[numeroJoueur].lesPieces[desActions[numeroJoueur].laPieceAModifier][unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]*v+s] = uneCopieSet.lesPieces[desActions[numeroJoueur].laPieceAModifier][unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]*s+v];
                                }
                            }
                            uneCopieSet = unSetPieces[numeroJoueur]; //On recopie la pièce pour appliquer une secone opération
                            for (v = 0 ; v != unSetPieces[numeroJoueur].lesHauteursPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]; v++){ //MIROIR HORIZONTALE
                                for (s = 0 ; s != unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier] ; s++){
                                    unSetPieces[numeroJoueur].lesPieces[desActions[numeroJoueur].laPieceAModifier][unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]*v+s] = uneCopieSet.lesPieces[desActions[numeroJoueur].laPieceAModifier][uneCopieSet.lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]*v-1+uneCopieSet.lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]-s];
                                }
                            }
                            break;
                        case 'h': //MIROIR HORIZONTALE
                            laDecision = true;
                            for (v = 0 ; v != unSetPieces[numeroJoueur].lesHauteursPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]; v++){
                                for (s = 0 ; s != unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier] ; s++){
                                    unSetPieces[numeroJoueur].lesPieces[desActions[numeroJoueur].laPieceAModifier][unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]*v+s] = uneCopieSet.lesPieces[desActions[numeroJoueur].laPieceAModifier][uneCopieSet.lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]*v-1+uneCopieSet.lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]-s];
                                }
                            }
                            break;
                        case 'v': //MIROIR VERTICAL
                            laDecision = true;
                            for (v = 0 ; v != unSetPieces[numeroJoueur].lesHauteursPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]; v++){
                                for (s = 0 ; s != unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier] ; s++){
                                    unSetPieces[numeroJoueur].lesPieces[desActions[numeroJoueur].laPieceAModifier][unSetPieces[numeroJoueur].lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]*v+s] = uneCopieSet.lesPieces[desActions[numeroJoueur].laPieceAModifier][s + ((uneCopieSet.lesHauteursPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]) - (1+v))*uneCopieSet.lesLargeursMaxPiecesJoueur[desActions[numeroJoueur].laPieceAModifier]];
                                }
                            }
                            break;
                        default: //Pour les caractères non détectés
                            std::cout << "Erreur de formatage, veuillez effectuer une sequence correcte ! ";
                            u = leDebutPlacement - 1;
                            break;
                        }
                    }
                }
                lePlacement = false , uneErreur = false , laErreurPieceModif = false; //On néttoie pour le prochain passage
                leDebutPlacement = 0;
            }
        }while(not laDecision);
        laDecision = false;
        //CALCUL (REFRESH) DE LA HAUTEUR DES PIECES MAXIMUM PAR TAILLE
        for (int i = 0 ; i != 5 ; i++){
            unSetPieces[numeroJoueur].lesHauteursMaxParTailles[i] = 0;
        }
        for (int i = 0 ; i != 21 ; i++){
            if (unSetPieces[numeroJoueur].lesHauteursMaxParTailles[unSetPieces[numeroJoueur].lesTailles[i] - 1] < unSetPieces[numeroJoueur].lesHauteursPiecesJoueur[i]){
                unSetPieces[numeroJoueur].lesHauteursMaxParTailles[unSetPieces[numeroJoueur].lesTailles[i] - 1] = unSetPieces[numeroJoueur].lesHauteursPiecesJoueur[i];
            }
        }
        construitGrille(unSetPieces , unContenuScene , desActions , numeroJoueur);
    }
}
