/**
 * \file identiteJoueur.cpp
 * \brief Construit l'identité de chaque joueur.
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>
#include <QString>


/**
 * \brief identiteJoueurs
 * \param unNbJoueurs
 * \param desNomsJoueurs
 */
void identiteJoueurs(int &unNbJoueurs , std::string desNomsJoueurs[]){
    do{
        std::string unNbJoueursStr; bool ok;
        std::cout << "Combien de joueurs sont de la partie ? ";
        std::getline(std::cin , unNbJoueursStr); //Un getline pour éviter les bugs si l'utilisateur entre certains caractères
        unNbJoueurs = QString::fromStdString(unNbJoueursStr).toInt(&ok);
        if (unNbJoueurs < 1 or unNbJoueurs > 4){
            system("cls"); //Clearing console
            std::cout << "Erreur de formatage : Veuillez saisir un chiffre entre 1 et 4. ";
        }
    }while(unNbJoueurs < 1 or unNbJoueurs > 4); //Enregistrement des pseudos
    for (int i = 0 ; i != unNbJoueurs ; i++){
        std::cout << std::endl;
        std::cout << "Donnez le pseudo du joueur " << i + 1 << " : ";
        std::getline(std::cin , desNomsJoueurs[i]);
    }
    system("cls"); //Clearing
}
