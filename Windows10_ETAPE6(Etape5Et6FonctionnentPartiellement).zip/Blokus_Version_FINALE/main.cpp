/**
 * \file main.cpp
 * \brief Fonction principal du projet de jeu de société Blockus.
 * \author Alfred.G
 * \version 4.0
 * \date 23 Décembre 2017
 */

#include <fonctions.h>


/**
 * \brief main
 * \return
 */
int main()
{
    int leNbJoueurs = 1; std::string lesNomsJoueurs[4]; bool laFinPartie = false; action laAction[leNbJoueurs]; contenu leContenuScene[506]; pieces lesSetPieces[4]; //Déclarations variables et initialisation de deux d'entres elles
    identiteJoueurs(leNbJoueurs , lesNomsJoueurs); //Récupération de l'identité des joueurs
    initGrille(leContenuScene); //On initialise une fois certains caractères et les couleurs
    construitPieces(lesSetPieces , leContenuScene , leNbJoueurs); //On construit une fois les pièces
    while (not laFinPartie){ //While UNIQUEMENT pour voir les effets des modifications des pièces au bout d'un tour de chaque joueur (J'ai intentionnellement laissé la possibilité de re-placer les mêmes pièces pour visualiser les effets des changements sur l'affichage des pièces
        modificationPiece(lesSetPieces , laAction , leNbJoueurs , leContenuScene , lesNomsJoueurs); //On demande et on execute la séquence de modifications de la pièce et on la place par la même occasion
    }
}
