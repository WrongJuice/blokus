#include <windows.h>
#include <iostream>

void changeCouleur(int uneCouleur) //Fonction permettant le changement de couleur
{
    HANDLE H = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H , uneCouleur);
}
