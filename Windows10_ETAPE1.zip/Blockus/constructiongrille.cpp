#include <iostream>

void constructionGrille(std::string uneChaineDeCaractere[])//Construction de la partie variable de la grille
{
    for (int u = 1 ; u != 21 ; ++u){ //Première boucle pour les colonnes
        for (int i = 1 ; i != 21 ; ++i){ //Deuxième boucle pour les lignes
            uneChaineDeCaractere[23 + u*22 + i] = " ."; //Affectation dans le tableau
        }
    }
}
