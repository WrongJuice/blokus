#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void initGrille(std::string uneChaineDeCaracteres[] , int unJoueur[])
{
    uneChaineDeCaracteres[1] = "  "; //Début première ligne
    for (int i = 1 ; i != 21 ; ++i){
        switch (i/10) {
        default: uneChaineDeCaracteres[i + 1] = " 1";
                break;
        case 0: uneChaineDeCaracteres[i + 1] = "  ";
                break;
        case 2: uneChaineDeCaracteres[i + 1] = " 2";
                break;
        }
    }
    uneChaineDeCaracteres[23] = "  "; //Début deuxième ligne
    for (int i = 1 ; i != 21 ; ++i){ //Deuxième ligne et colonne de lettres
        char unNombre = i%10 + 48;
        uneChaineDeCaracteres[i + 23] = {' ' , unNombre};
        unNombre = i + 64;
        uneChaineDeCaracteres[23 + i*22] = {' ' , unNombre};
    }
    for (int i = 1 ; i != 23 ; ++i) //Construction de la ligne et la colonne "invisible"
    {
        uneChaineDeCaracteres[i*22] = "  ";
        uneChaineDeCaracteres[484 + i] = "  ";
    }
    srand(time(NULL)); //Initialisation de rand
    for (int i = 1 ; i != 5 ; ++i)//Attribution au hasard d'un chiffre entre 1 et 4 pour chacun des 4 joueurs
    {
        switch (i) { //Switch nécessaire avec 3 boucles pour éviter que deux joueurs ou plus puissent avoir la même couleur
        case 1: unJoueur[i] = (rand()%4) + 1;
            break;
        case 2:
            unJoueur[i] = (rand()%4) + 1;
            while (unJoueur[i] == unJoueur[i - 1]) //On reboucle jusqu'à obtenir un chiffre différent du précedent
            {
                unJoueur[i] = (rand()%4) + 1;;
            }
            break;
        case 3:
            unJoueur[i] = (rand()%4) + 1;;
            while (unJoueur[i] == unJoueur[i - 1] or unJoueur[i] == unJoueur[i - 2]) //différent du précedent et du premier
            {
                unJoueur[i] = (rand()%4) + 1;
            }
            break;
        case 4:
            unJoueur[i] = (rand()%4) + 1;
            while (unJoueur[i] == unJoueur[i - 1] or unJoueur[i] == unJoueur[i - 2] or unJoueur[i] == unJoueur[i - 3]) //différent des trois premiers
            {
                unJoueur[i] = (rand()%4) + 1;
            }
            break;
        }
    }
    for (int i = 1 ; i != 5 ; ++i) //Attribution d'une couleur en fonction du chiffre attribué plus haut
    {
        switch (unJoueur[i]) {
        case 1: unJoueur[i] = 170; //Vert
            break;
        case 2: unJoueur[i] = 238; //Jaune
            break;
        case 3: unJoueur[i] = 153; //Bleu
            break;
        case 4: unJoueur[i] = 204; //Rouge
            break;
        }
    }
}
