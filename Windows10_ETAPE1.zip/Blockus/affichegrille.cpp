#include <fonctions.h>

void afficheGrille(std::string uneChaineDeCaracteres[] , int unJoueur[])
{
    constructionGrille(uneChaineDeCaracteres); //On lance la construction de la grille (partie de la grille qui varie)
    for (int u = 0 ; u != 23 ; ++u){
        for (int i = 1 ; i != 23 ; ++i){ //Affichage du départ de chaque joueur par couleur
            int v = i + u*22;
            switch (v) {
            case 23:
                changeCouleur(unJoueur[1]);
                break;
            case 44:
                changeCouleur(unJoueur[2]);
                break;
            case 485:
                changeCouleur(unJoueur[3]);
                break;
            case 506:
                changeCouleur(unJoueur[4]);
                break;
            }
            std::cout << uneChaineDeCaracteres[i + u*22]; //affichage du contenu de la grille
            changeCouleur(15); //réinitialisation de la couleur par défaut
        }
        std::cout << std::endl;
    }
}
