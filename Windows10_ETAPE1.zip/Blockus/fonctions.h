#ifndef FONCTIONS_H
#define FONCTIONS_H
#include <iostream>

void initGrille(std::string uneChaineDeCaracteres[] , int unJoueur[]);
void constructionGrille(std::string uneChaineDeCaractere[]);
void afficheGrille(std::string uneChaineDeCaracteres[] , int unJoueur[]);
void changeCouleur(int uneCouleur);

#endif // FONCTIONS_H

