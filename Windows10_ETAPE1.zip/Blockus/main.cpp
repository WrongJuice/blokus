#include <fonctions.h>


int main()
{
    std::string laChaineDeCaracteres[507]; //Déclaration du tableau de chaînes de caractères qui contien la grille
    int laCouleurJoueur[4]; //4 joueurs = 4 couleurs
    initGrille(laChaineDeCaracteres , laCouleurJoueur); //On initialise une fois certains caractères et les couleurs
    afficheGrille(laChaineDeCaracteres , laCouleurJoueur); //Construction et affichage de la grille
}
